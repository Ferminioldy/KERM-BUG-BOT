<p align="center">
    <img src="https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png">
</p>

<h1 align="center">Kerm_Bug-V2</h1>

<p align="center">
  <a href="https://kg-site-support.vercel.app/">
    <img src="https://img.shields.io/badge/KG WEBSITE-000?style=for-the-badge&logo=vercel&logoColor=white" alt="Generate Session ID"/>
  </a>

<p align="center">
  <a href="https://github.com/Kgtech-cmr"><img src="http://readme-typing-svg.herokuapp.com?color=FFFFFF&center=true&vCenter=true&multiline=false&lines=Kerm+Bug+v2+MultiDevice;New+Plugin+Base+Modification;Developed+by+Kg~Tech;Give+star+and+forks+this+Repo+🌟" alt="KermReadme"></a>
</p>

---

<p align="center"><img src="https://moe-counter.glitch.me/get/@Anya_v2-Md?theme=gelbooru" alt="Anya_v2_Visits_Counter" /></p>

##
## `Fork This Repo?`
  1. Fork the `Repo`.
     - ***([`Tap Here To Fork`](https://github.com/Kgtech-cmr/Kerm-Bug-V2/fork))***

---

### `Where To Deploy ?`

2. ***([Deploy On Panel](https://bot-hosting.net))***
 ```
Hey bro 
want To Connect this bot  with your Whatsapp Number

here is no any cmd

Go and watch Tutorial Video On KermHackTools Youtube Channal


you can also see these tutorials.. 👇 
   😘 💕   Panel host method https://youtu.be/KermHackTools-s9s

```
⚠️We don't scan the session on the repo.
You just import the zip in the panel, you put your num as premium and owner then you start the deployment.
It is on the codespace of the panel that you will be asked to put your number for the session.

### `Need Support?` ***Join support group..!***

  - [![WhatsApp Group](https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://chat.whatsapp.com/L5MM9j04Caz4y2EZHRnD1Z) ***GROUP SUPPORT***
   - [![WhatsApp Channel](https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://whatsapp.com/channel/0029Vafn6hc7DAX3fzsKtn45) ***CHANNEL***
   - [![YouTube](https://img.shields.io/badge/YouTube-FF0000?style=for-the-badge&logo=youtube&logoColor=white)](https://youtube.com/@KermHackTools-s9s)

##

### `License:`

This project is licensed under the [` GPL-3.0 License`](LICENSE).

Feel free to star ⭐ and fork 🍴 this repository to show your support!

##

### `Repository Details:`

<details>
  <summary>Click here to view</summary>

<div align="center">
    
| Owner 👤             | Repo 🤖              | Forks 🍽️             | Stars 🌟            | Language 🗣️        | Licence 🪪              
|----------------------|----------------------|----------------------|---------------------|---------------------|---------------------|
| [![Owner](https://img.shields.io/badge/Author-KgTech237-red.svg)](https://github.com/Kgtech-cmr) | [![Repository](https://img.shields.io/badge/Repo-Kerm_bug_v2-red.svg)](https://github.com/Kgtech-cmr/Kerm-Bug-V2/) | [![GitHub forks](https://badgen.net/github/forks/Kgtech-cmr/Kerm-Bug-V2/)](https://GitHub.com/Kgtech-cmr/Kerm-Bug-V2/network/) | [![GitHub stars](https://badgen.net/github/stars/Kgtech-cmr/Kerm-Bug-V2)](https://GitHub.com/Kgtech-cmr/Kerm-Bug-V2/stargazers/) | ![JavaScript](https://img.shields.io/badge/javascript-%23323330.svg?style=for-the-badge&logo=javascript&logoColor=%23F7DF1E) | [![GitHub license](https://img.shields.io/github/license/Kgtech-cmr/Kerm-Bug-V2.svg)](https://github.com/Kgtech-cmr/Kerm-Bug-V2/blob/master/LICENSE) 


</div>
</details>
